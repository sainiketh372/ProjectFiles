package com.tcs.jfd.fooddelivery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderEatsApplicationTests {

	@Test
	void contextLoads() {
	}

}

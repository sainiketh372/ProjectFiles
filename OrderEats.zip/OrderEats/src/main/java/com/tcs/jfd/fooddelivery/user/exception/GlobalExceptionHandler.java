package com.tcs.jfd.fooddelivery.user.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.tcs.jfd.fooddelivery.user.dto.ApiResponse;

@RestControllerAdvice
public class GlobalExceptionHandler {

	//Handle CustomException
	@ExceptionHandler(CustomException.class)
	public ResponseEntity<ApiResponse<Object>> handleCustomException(CustomException ex){
		ApiResponse<Object> response = ApiResponse.error(ex.getMessage());
		return new ResponseEntity<>(response,ex.getHttpStatus());
	}
	
	//Handle Validation Errors
	@ExceptionHandler(exception = MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String, String>> handleBeanObject(MethodArgumentNotValidException me) {
		BindingResult br = me.getBindingResult();
		Map<String, String> res = new HashMap<>();
		br.getFieldErrors().forEach(x -> res.put(x.getField(), x.getDefaultMessage()));
		return new ResponseEntity<>(res, HttpStatus.BAD_REQUEST);
	}
	
	//Handle General Exceptions
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ApiResponse<Object>> handleGeneralExec(Exception ex){
		ApiResponse<Object> response = ApiResponse.error("An Unexpectec error Occured:" + ex.getMessage());
		return new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
}

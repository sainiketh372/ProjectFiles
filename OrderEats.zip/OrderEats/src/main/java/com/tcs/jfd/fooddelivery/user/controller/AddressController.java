package com.tcs.jfd.fooddelivery.user.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.jfd.fooddelivery.user.dto.AddressDTO;
import com.tcs.jfd.fooddelivery.user.dto.ApiResponse;
import com.tcs.jfd.fooddelivery.user.service.AddressService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class AddressController {

	private final AddressService addressService;

	@PostMapping("/{userId}/addresses")
	public ResponseEntity<ApiResponse<AddressDTO>> addAddress(@PathVariable Long userId,
			@Valid @RequestBody AddressDTO addressDTO) {
		return addressService.addAddress(userId, addressDTO);
	}

	@GetMapping("/{userId}/addresses")
	public ResponseEntity<ApiResponse<List<AddressDTO>>> getUserAddresses(@PathVariable Long userId) {
		return addressService.getUserAddresses(userId);
	}

	@GetMapping("/{userId}/addresses/default")
	public ResponseEntity<ApiResponse<AddressDTO>> getDefaultAddress(@PathVariable Long userId) {
		return addressService.getDefaultAddress(userId);
	}

	@PutMapping("/addresses/{addressId}")
	public ResponseEntity<ApiResponse<AddressDTO>> updateAddress(@PathVariable Long addressId,
			@Valid @RequestBody AddressDTO addressDTO) {
		return addressService.updateAddress(addressId, addressDTO);
	}

	@PutMapping("/{userId}/addresses/{addressId}/default")
	public ResponseEntity<ApiResponse<AddressDTO>> setDefaultAddress(@PathVariable Long userId,
			@PathVariable Long addressId) {
		return addressService.setDefaultAddress(userId, addressId);
	}

	@DeleteMapping("/addresses/{addressId}")
	public ResponseEntity<ApiResponse<String>> deleteAddress(@PathVariable Long addressId) {
		return addressService.deleteAddress(addressId);
	}
}

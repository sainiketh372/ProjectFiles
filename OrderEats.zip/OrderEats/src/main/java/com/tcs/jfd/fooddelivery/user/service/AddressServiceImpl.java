package com.tcs.jfd.fooddelivery.user.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tcs.jfd.fooddelivery.user.bean.Address;
import com.tcs.jfd.fooddelivery.user.bean.User;
import com.tcs.jfd.fooddelivery.user.dto.AddressDTO;
import com.tcs.jfd.fooddelivery.user.dto.ApiResponse;
import com.tcs.jfd.fooddelivery.user.exception.CustomException;
import com.tcs.jfd.fooddelivery.user.repository.AddressRepository;
import com.tcs.jfd.fooddelivery.user.repository.UserRepository;
import com.tcs.jfd.fooddelivery.user.util.EntityDtoConverter;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional
public class AddressServiceImpl implements AddressService {

	private final AddressRepository addressRepository;
	private final UserRepository userRepository;
	private final EntityDtoConverter converter;

	@Override
	public ResponseEntity<ApiResponse<AddressDTO>> addAddress(Long userId, AddressDTO addressDTO) {
		User user = userRepository.findById(userId).orElseThrow(() -> CustomException.userNotFound(userId));

		if (addressDTO.getIsDefault()) {
			List<Address> existingAddresses = addressRepository.findByUser_UserId(userId);
			existingAddresses.forEach(addr -> addr.setIsDefault(false));
			addressRepository.saveAll(existingAddresses);
		}

		Address address = new Address();
		address.setUser(user);
		address.setAddressType(addressDTO.getAddressType());
		address.setStreet(addressDTO.getStreet());
		address.setCity(addressDTO.getCity());
		address.setState(addressDTO.getState());
		address.setZipCode(addressDTO.getZipCode());
		address.setIsDefault(addressDTO.getIsDefault());

		Address savedAddress = addressRepository.save(address);
		AddressDTO responseDTO = converter.convertToAddressDTO(savedAddress);

		ApiResponse<AddressDTO> response = ApiResponse.success("Address added successfully", responseDTO);

		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	@Override
	@Transactional(readOnly = true)
	public ResponseEntity<ApiResponse<List<AddressDTO>>> getUserAddresses(Long userId) {
		if (!userRepository.existsById(userId)) {
			throw CustomException.userNotFound(userId);
		}

		List<AddressDTO> addresses = addressRepository.findByUser_UserId(userId).stream()
				.map(converter::convertToAddressDTO).collect(Collectors.toList());

		ApiResponse<List<AddressDTO>> response = ApiResponse.success("Addresses retrieved successfully", addresses);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<ApiResponse<AddressDTO>> updateAddress(Long addressId, AddressDTO addressDTO) {
		Address address = addressRepository.findById(addressId)
				.orElseThrow(() -> CustomException.addressNotFound(addressId));

		if (addressDTO.getIsDefault() && !address.getIsDefault()) {
			List<Address> userAddresses = addressRepository.findByUser_UserId(address.getUser().getUserId());
			userAddresses.forEach(addr -> addr.setIsDefault(false));
			addressRepository.saveAll(userAddresses);
		}

		address.setAddressType(addressDTO.getAddressType());
		address.setStreet(addressDTO.getStreet());
		address.setCity(addressDTO.getCity());
		address.setState(addressDTO.getState());
		address.setZipCode(addressDTO.getZipCode());
		address.setIsDefault(addressDTO.getIsDefault());

		Address updatedAddress = addressRepository.save(address);

		AddressDTO responseDTO = converter.convertToAddressDTO(updatedAddress);

		ApiResponse<AddressDTO> response = ApiResponse.success("Address updated Successfully", responseDTO);

		return new ResponseEntity<>(response, HttpStatus.OK);

	}

	@Override
	public ResponseEntity<ApiResponse<String>> deleteAddress(Long addressId) {
		if (!addressRepository.existsById(addressId)) {
			throw CustomException.addressNotFound(addressId);
		}

		addressRepository.deleteById(addressId);

		ApiResponse<String> response = ApiResponse.success("Address deleted successfully");

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<ApiResponse<AddressDTO>> setDefaultAddress(Long userId, Long addressId) {
		if (!userRepository.existsById(userId)) {
			throw CustomException.userNotFound(userId);
		}

		Address address = addressRepository.findById(addressId)
				.orElseThrow(() -> CustomException.addressNotFound(addressId));

		if (!address.getUser().getUserId().equals(userId)) {
			throw CustomException.unauthorizedAccess("Address does not belong to this user");
		}

		List<Address> userAddresses = addressRepository.findByUser_UserId(userId);
		userAddresses.forEach(addr -> addr.setIsDefault(false));
		addressRepository.saveAll(userAddresses);

		address.setIsDefault(true);
		Address updatedAddress = addressRepository.save(address);

		AddressDTO responseDTO = converter.convertToAddressDTO(updatedAddress);

		ApiResponse<AddressDTO> response = ApiResponse.success("Default address set successfully", responseDTO);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	@Transactional(readOnly = true)
	public ResponseEntity<ApiResponse<AddressDTO>> getDefaultAddress(Long userId) {
		Address defaultAddress = addressRepository.findByUser_UserIdAndIsDefault(userId, true)
				.orElseThrow(CustomException::noDefaultAddress);

		AddressDTO responseDTO = converter.convertToAddressDTO(defaultAddress);

		ApiResponse<AddressDTO> response = ApiResponse.success("Default address retrieved successfully", responseDTO);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}

package com.tcs.jfd.fooddelivery.user.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.tcs.jfd.fooddelivery.user.dto.ApiResponse;
import com.tcs.jfd.fooddelivery.user.dto.ChangePasswordDTO;
import com.tcs.jfd.fooddelivery.user.dto.LoginResponseDTO;
import com.tcs.jfd.fooddelivery.user.dto.UpdateProfileDTO;
import com.tcs.jfd.fooddelivery.user.dto.UserLoginDTO;
import com.tcs.jfd.fooddelivery.user.dto.UserRegistrationDTO;
import com.tcs.jfd.fooddelivery.user.dto.UserResponseDTO;
public interface UserService {
	ResponseEntity<ApiResponse<UserResponseDTO>> registerUser(UserRegistrationDTO registrationDTO);
    ResponseEntity<ApiResponse<LoginResponseDTO>> loginUser(UserLoginDTO loginDTO);
    ResponseEntity<ApiResponse<UserResponseDTO>> getUserById(Long userId);
    ResponseEntity<ApiResponse<UserResponseDTO>> updateProfile(Long userId, UpdateProfileDTO updateProfileDTO);
    ResponseEntity<ApiResponse<String>> changePassword(Long userId, ChangePasswordDTO changePasswordDTO);
    ResponseEntity<ApiResponse<String>> deleteUser(Long userId);
    ResponseEntity<ApiResponse<List<UserResponseDTO>>> getAllUsers();
	
}

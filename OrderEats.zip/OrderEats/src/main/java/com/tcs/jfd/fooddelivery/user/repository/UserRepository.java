package com.tcs.jfd.fooddelivery.user.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tcs.jfd.fooddelivery.user.bean.User;
import java.util.List;
import com.tcs.jfd.fooddelivery.user.bean.Role;


@Repository
public interface UserRepository extends JpaRepository<User, Long> {

	Optional<User> findByEmail(String email);
	
	Optional<User> findByUsername(String Username);
	
	boolean existsByEmail(String email);
	
	boolean existsByUsername(String username);
	
	List<User> findByRole(Role role);
	
	List<User> findByIsActive(Boolean isActive);
	
	Optional<User> findByEmailAndIsActive(String email,Boolean isActive);
	
	Optional<User> findByPhoneNumber(String phoneNumber);
}

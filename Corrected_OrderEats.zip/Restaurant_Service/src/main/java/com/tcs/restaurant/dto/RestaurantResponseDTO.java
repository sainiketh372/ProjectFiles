package com.tcs.restaurant.dto;

import lombok.Data;

@Data
public class RestaurantResponseDTO {

    private Long id;
    private String name;
    private String description;
    private String address;
    private String phoneNumber;
    private Boolean active;
}

package com.tcs.restaurant.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.tcs.restaurant.dto.RestaurantRequestDTO;
import com.tcs.restaurant.dto.RestaurantResponseDTO;
import com.tcs.restaurant.entity.Restaurant;
import com.tcs.restaurant.repository.RestaurantRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class RestaurantServiceImpl implements RestaurantService {

    private final RestaurantRepository restaurantRepository;

    @Override
    public RestaurantResponseDTO createRestaurant(RestaurantRequestDTO dto) {
        Restaurant restaurant = new Restaurant();
        restaurant.setName(dto.getName());
        restaurant.setDescription(dto.getDescription());
        restaurant.setAddress(dto.getAddress());
        restaurant.setPhoneNumber(dto.getPhoneNumber());
        restaurant.setActive(true);

        return mapToResponseDTO(restaurantRepository.save(restaurant));
    }

    @Override
    public RestaurantResponseDTO getRestaurantById(Long id) {
        return restaurantRepository.findById(id)
                .map(this::mapToResponseDTO)
                .orElseThrow(() -> new RuntimeException("Restaurant not found"));
    }

    @Override
    public List<RestaurantResponseDTO> getActiveRestaurants() {
        return restaurantRepository.findByActiveTrue()
                .stream()
                .map(this::mapToResponseDTO)
                .collect(Collectors.toList());
    }

    private RestaurantResponseDTO mapToResponseDTO(Restaurant restaurant) {
        RestaurantResponseDTO dto = new RestaurantResponseDTO();
        dto.setId(restaurant.getId());
        dto.setName(restaurant.getName());
        dto.setDescription(restaurant.getDescription());
        dto.setAddress(restaurant.getAddress());
        dto.setPhoneNumber(restaurant.getPhoneNumber());
        dto.setActive(restaurant.getActive());
        return dto;
    }
}

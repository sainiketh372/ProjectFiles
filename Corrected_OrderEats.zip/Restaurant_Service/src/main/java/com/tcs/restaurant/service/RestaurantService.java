package com.tcs.restaurant.service;

import java.util.List;

import com.tcs.restaurant.dto.RestaurantRequestDTO;
import com.tcs.restaurant.dto.RestaurantResponseDTO;

public interface RestaurantService {

    RestaurantResponseDTO createRestaurant(RestaurantRequestDTO dto);

    RestaurantResponseDTO getRestaurantById(Long id);

    List<RestaurantResponseDTO> getActiveRestaurants();
}

package com.tcs.jfd.fooddelivery.user.util;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.tcs.jfd.fooddelivery.user.bean.Address;
import com.tcs.jfd.fooddelivery.user.bean.User;
import com.tcs.jfd.fooddelivery.user.dto.AddressDTO;
import com.tcs.jfd.fooddelivery.user.dto.UserResponseDTO;

@Component
public class EntityDtoConverter {

    public UserResponseDTO convertToUserResponseDTO(User user) {
        UserResponseDTO dto = new UserResponseDTO();
        dto.setUserId(user.getUserId());
        dto.setUsername(user.getUsername());
        dto.setEmail(user.getEmail());
        dto.setPhoneNumber(user.getPhoneNumber());
        dto.setRole(user.getRole());
        dto.setIsActive(user.getIsActive());
        dto.setCreatedAt(user.getCreatedAt());
        dto.setUpdatedAt(user.getUpdatedAt());
        
        // Convert addresses if loaded
        if (user.getAddresses() != null && !user.getAddresses().isEmpty()) {
            List<AddressDTO> addressDTOs = user.getAddresses().stream()
                    .map(this::convertToAddressDTO)
                    .collect(Collectors.toList());
            dto.setAddresses(addressDTOs);
        }
        
        return dto;
    }

    public AddressDTO convertToAddressDTO(Address address) {
        AddressDTO dto = new AddressDTO();
        dto.setAddressId(address.getAddressId());
        dto.setAddressType(address.getAddressType());
        dto.setStreet(address.getStreet());
        dto.setCity(address.getCity());
        dto.setState(address.getState());
        dto.setZipCode(address.getZipCode());
        dto.setIsDefault(address.getIsDefault());
        return dto;
    }
}

package com.tcs.jfd.fooddelivery.user.bean;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="addresses")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Address {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long addressId;
	
	@ManyToOne(fetch=FetchType.LAZY)//fetch = loads JPA data
	@JoinColumn(name="user_id",nullable=false)
	@JsonBackReference
	private User user; //relationship
	
	@Enumerated(EnumType.STRING)
	private AddressType addressType = AddressType.HOME;
	
	@NotBlank(message = "Street address is required")
    @Size(min=3,max = 200, message = "Street address cannot exceed 200 characters")
    @Column(nullable = false, length = 200)
	private String street;
	
    @Column(nullable = false, length = 50)
	@NotBlank(message = "City is required")
    @Size(min=3,max = 50, message = "City name cannot exceed 50 characters")
	private String city;
	
    @NotBlank(message = "State is required")
    @Size(min=3,max = 50, message = "State name cannot exceed 50 characters")
    @Column(nullable = false, length = 50)
	private String state;
	
    @NotBlank(message = "Zip code is required")
    @Size(min = 5, max = 10, message = "Zip code must be between 5 and 10 characters")
    @Column(nullable = false, length = 10)
	private String zipCode;
	
	@Column
	private Boolean isDefault = false;
	
	@CreationTimestamp
	@Column(updatable=false)
	private LocalDateTime createdAt;
	
}

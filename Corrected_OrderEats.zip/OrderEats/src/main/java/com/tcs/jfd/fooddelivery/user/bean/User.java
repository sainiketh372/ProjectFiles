package com.tcs.jfd.fooddelivery.user.bean;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="users")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long userId;
	
    @NotBlank(message = "Username is required")
	@Column(unique=true, nullable=false)
    @Size(min = 3, max = 50, message = "Username must be between 3 and 50 characters")
	private String username;
	
    @NotBlank(message = "Email is required")
    @Email(message = "Email should be valid")
	@Column(unique=true, nullable=false)
	private String email;
    
    @NotBlank(message = "Password is required")
    @Size(min = 6, message = "Password must be at least 6 characters")
    @Column(nullable = false)
	private String password;
    
    @Size(min = 10, max = 15, message = "Phone number should be between 10 and 15 digits")
    @Column(length=15)
	private String phoneNumber;
	
	@Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
	private Role role = Role.CUSTOMER;
	
	@Column
	private Boolean isActive;
	
	@CreationTimestamp
	@Column(updatable=false)
	private LocalDateTime createdAt;
	
	@UpdateTimestamp
	@Column
	private LocalDateTime updatedAt;
	
	//These Keywords ensure data Integrity between parent and child
	@OneToMany(mappedBy="user",cascade = CascadeType.ALL,orphanRemoval = true,fetch=FetchType.LAZY)
	@JsonManagedReference
	private List<Address> addresses = new ArrayList<>();
	
	
	
}

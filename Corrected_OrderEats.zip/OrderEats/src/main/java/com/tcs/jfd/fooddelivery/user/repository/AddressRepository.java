package com.tcs.jfd.fooddelivery.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tcs.jfd.fooddelivery.user.bean.Address;
import com.tcs.jfd.fooddelivery.user.bean.AddressType;

@Repository
public interface AddressRepository extends JpaRepository<Address, Long>{

	List<Address> findByUser_UserId(Long userId);
	
	Optional<Address> findByUser_UserIdAndIsDefault(Long userId, Boolean isDefault);
	
	Optional<Address> findByUser_UserIdAndAddressType(Long userId,AddressType addressType);
	
	boolean existsByUser_UserId(Long userId);
	
	long countByUser_UserId(Long userId);
	
	void deleteByUser_UserId(Long userId);
}

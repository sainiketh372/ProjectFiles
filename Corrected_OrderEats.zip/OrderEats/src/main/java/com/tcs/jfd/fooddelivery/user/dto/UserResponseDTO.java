package com.tcs.jfd.fooddelivery.user.dto;

import java.time.LocalDateTime;
import java.util.List;

import com.tcs.jfd.fooddelivery.user.bean.Role;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserResponseDTO {
	
	  private Long userId;
	    private String username;
	    private String email;
	    private String phoneNumber;
	    private Role role;
	    private Boolean isActive;
	    private LocalDateTime createdAt;
	    private LocalDateTime updatedAt;
	    private List<AddressDTO> addresses;
	    
	    //Address is not included to reduce complexity and simpler responses
		public UserResponseDTO(Long userId, String username, String email, String phoneNumber, Role role,
				Boolean isActive, LocalDateTime createdAt, LocalDateTime updatedAt) {
			super();
			this.userId = userId;
			this.username = username;
			this.email = email;
			this.phoneNumber = phoneNumber;
			this.role = role;
			this.isActive = isActive;
			this.createdAt = createdAt;
			this.updatedAt = updatedAt;
		}
	    
	    

}

package com.tcs.jfd.fooddelivery.user.exception;

import org.springframework.http.HttpStatus;

import lombok.Getter;

@Getter
public class CustomException extends RuntimeException {
    
    private final HttpStatus httpStatus;
    
    public CustomException(String message, HttpStatus httpStatus) {
        super(message);
        this.httpStatus = httpStatus;
    }
    
    // Static common exceptions
    
    public static CustomException userNotFound(Long userId) {
        return new CustomException("User not found with id: " + userId, HttpStatus.NOT_FOUND);
    }
    
    public static CustomException userNotFound(String identifier) {
        return new CustomException("User not found: " + identifier, HttpStatus.NOT_FOUND);
    }
    
    public static CustomException duplicateEmail(String email) {
        return new CustomException("Email already registered: " + email, HttpStatus.CONFLICT);
    }
    
    public static CustomException duplicateUsername(String username) {
        return new CustomException("Username already taken: " + username, HttpStatus.CONFLICT);
    }
    
    public static CustomException invalidCredentials() {
        return new CustomException("Invalid email or password", HttpStatus.UNAUTHORIZED);
    }
    
    public static CustomException userNotActive() {
        return new CustomException("User account is deactivated", HttpStatus.FORBIDDEN);
    }
    
    public static CustomException passwordMismatch() {
        return new CustomException("New password and confirm password do not match", HttpStatus.BAD_REQUEST);
    }
    
    public static CustomException incorrectPassword() {
        return new CustomException("Current password is incorrect", HttpStatus.BAD_REQUEST);
    }
    
    public static CustomException addressNotFound(Long addressId) {
        return new CustomException("Address not found with id: " + addressId, HttpStatus.NOT_FOUND);
    }
    
    public static CustomException noDefaultAddress() {
        return new CustomException("No default address found for user", HttpStatus.NOT_FOUND);
    }
    
    public static CustomException unauthorizedAccess(String message) {
        return new CustomException(message, HttpStatus.FORBIDDEN);
    }
}
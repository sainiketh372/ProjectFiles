package com.tcs.jfd.fooddelivery.user.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.tcs.jfd.fooddelivery.user.dto.AddressDTO;
import com.tcs.jfd.fooddelivery.user.dto.ApiResponse;

public interface AddressService {
	ResponseEntity<ApiResponse<AddressDTO>> addAddress(Long userId, AddressDTO addressDTO);
    ResponseEntity<ApiResponse<List<AddressDTO>>> getUserAddresses(Long userId);
    ResponseEntity<ApiResponse<AddressDTO>> updateAddress(Long addressId, AddressDTO addressDTO);
    ResponseEntity<ApiResponse<String>> deleteAddress(Long addressId);
    ResponseEntity<ApiResponse<AddressDTO>> setDefaultAddress(Long userId, Long addressId);
    ResponseEntity<ApiResponse<AddressDTO>> getDefaultAddress(Long userId);
}

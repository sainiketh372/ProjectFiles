package com.tcs.jfd.fooddelivery.user.dto;

import com.tcs.jfd.fooddelivery.user.bean.AddressType;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AddressDTO {

	private Long addressId;

	private AddressType addressType = AddressType.HOME;

	@NotBlank(message = "Street address is required")
	@Size(max = 200, message = "Street address cannot exceed 200 characters")
	private String street;

	@NotBlank(message = "City is required")
	@Size(max = 50, message = "City name cannot exceed 50 characters")
	private String city;

	@NotBlank(message = "State is required")
	@Size(max = 50, message = "State name cannot exceed 50 characters")
	private String state;

	@NotBlank(message = "Zip code is required")
	@Size(min = 5, max = 10, message = "Zip code must be between 5 and 10 characters")
	private String zipCode;

	private Boolean isDefault = false;

	// Constructor without addressId (for creating new addresses)
	public AddressDTO(AddressType addressType, String street, String city, String state, String zipCode,
			Boolean isDefault) {
		this.addressType = addressType;
		this.street = street;
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
		this.isDefault = isDefault;
	}

}

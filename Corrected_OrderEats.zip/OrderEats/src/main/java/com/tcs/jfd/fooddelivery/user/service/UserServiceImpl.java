package com.tcs.jfd.fooddelivery.user.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tcs.jfd.fooddelivery.user.bean.User;
import com.tcs.jfd.fooddelivery.user.dto.ApiResponse;
import com.tcs.jfd.fooddelivery.user.dto.ChangePasswordDTO;
import com.tcs.jfd.fooddelivery.user.dto.LoginResponseDTO;
import com.tcs.jfd.fooddelivery.user.dto.UpdateProfileDTO;
import com.tcs.jfd.fooddelivery.user.dto.UserLoginDTO;
import com.tcs.jfd.fooddelivery.user.dto.UserRegistrationDTO;
import com.tcs.jfd.fooddelivery.user.dto.UserResponseDTO;
import com.tcs.jfd.fooddelivery.user.exception.CustomException;
import com.tcs.jfd.fooddelivery.user.repository.UserRepository;
import com.tcs.jfd.fooddelivery.user.util.EntityDtoConverter;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor //For Constructor Injection.
@Transactional
public class UserServiceImpl implements UserService{
	
	//Constructor Injection(@Autowired is not used) for Immutability
	private final UserRepository userRepository;
	private final PasswordEncoder passwordEncoder;
	private final EntityDtoConverter converter;
	
	@Override
	public ResponseEntity<ApiResponse<UserResponseDTO>> registerUser(UserRegistrationDTO registrationDTO) {
		if(userRepository.existsByEmail(registrationDTO.getEmail())) {
			throw CustomException.duplicateEmail(registrationDTO.getEmail());
		}
		if(userRepository.existsByUsername(registrationDTO.getUsername())) {
			throw CustomException.duplicateUsername(registrationDTO.getUsername());
		}
		
		// new User
		User user = new User();
		user.setUsername(registrationDTO.getUsername());
        user.setEmail(registrationDTO.getEmail());
        user.setPassword(passwordEncoder.encode(registrationDTO.getPassword()));
        user.setPhoneNumber(registrationDTO.getPhoneNumber());
        user.setRole(registrationDTO.getRole());
        user.setIsActive(true);
        
        //save
        User savedUser = userRepository.save(user);
        
        UserResponseDTO responseDTO = converter.convertToUserResponseDTO(savedUser);
        
        ApiResponse<UserResponseDTO> response = ApiResponse.success("User Registered Successfully",responseDTO);
        
        return new ResponseEntity<>(response,HttpStatus.CREATED);
	}
	

	@Override
	public ResponseEntity<ApiResponse<LoginResponseDTO>> loginUser(UserLoginDTO loginDTO) {
		User user = userRepository.findByEmail(loginDTO.getEmail())
                .orElseThrow(CustomException::invalidCredentials);
		
		if (!user.getIsActive()) {
            throw CustomException.userNotActive();
        }
		
        String token = "temporary-token-" + user.getUserId();

        UserResponseDTO userResponseDTO = converter.convertToUserResponseDTO(user);

        LoginResponseDTO loginResponse = new LoginResponseDTO(token, userResponseDTO);

        ApiResponse<LoginResponseDTO> response = ApiResponse.success("Login successful", loginResponse);
        
        return new ResponseEntity<>(response,HttpStatus.OK);
	}

	@Override
	@Transactional(readOnly=true)
	public ResponseEntity<ApiResponse<UserResponseDTO>> getUserById(Long userId) {
		User user = userRepository.findById(userId)
                .orElseThrow(() -> CustomException.userNotFound(userId));
		
        UserResponseDTO responseDTO = converter.convertToUserResponseDTO(user);

        ApiResponse<UserResponseDTO> response = ApiResponse.success("User Retrived Successfully",responseDTO);
        return new ResponseEntity<>(response,HttpStatus.OK);
	}

	@Override
	public ResponseEntity<ApiResponse<UserResponseDTO>> updateProfile(Long userId, UpdateProfileDTO updateProfileDTO) {
		User user = userRepository.findById(userId)
                .orElseThrow(() -> CustomException.userNotFound(userId));
		
		if (updateProfileDTO.getUsername() != null && !updateProfileDTO.getUsername().isEmpty()) {
            if (!user.getUsername().equals(updateProfileDTO.getUsername()) 
                && userRepository.existsByUsername(updateProfileDTO.getUsername())) {
                throw CustomException.duplicateUsername(updateProfileDTO.getUsername());
            }
            user.setUsername(updateProfileDTO.getUsername());
        }
		
		if (updateProfileDTO.getEmail() != null && !updateProfileDTO.getEmail().isEmpty()) {
            if (!user.getEmail().equals(updateProfileDTO.getEmail()) 
                && userRepository.existsByEmail(updateProfileDTO.getEmail())) {
                throw CustomException.duplicateEmail(updateProfileDTO.getEmail());
            }
            user.setEmail(updateProfileDTO.getEmail());
        }
		
		if (updateProfileDTO.getPhoneNumber() != null && !updateProfileDTO.getPhoneNumber().isEmpty()) {
            user.setPhoneNumber(updateProfileDTO.getPhoneNumber());
        }

        User updatedUser = userRepository.save(user);
        UserResponseDTO responseDTO = converter.convertToUserResponseDTO(updatedUser);

        ApiResponse<UserResponseDTO> response = ApiResponse.success("Profile updated successfully",responseDTO);
        
        return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<ApiResponse<String>> changePassword(Long userId, ChangePasswordDTO changePasswordDTO) {
		User user = userRepository.findById(userId)
                .orElseThrow(() -> CustomException.userNotFound(userId));
		
		if (!passwordEncoder.matches(changePasswordDTO.getCurrentPassword(), user.getPassword())) {
            throw CustomException.incorrectPassword();
        }
		
		if (!changePasswordDTO.getNewPassword().equals(changePasswordDTO.getConfirmPassword())) {
            throw CustomException.passwordMismatch();
        }
		
		user.setPassword(passwordEncoder.encode(changePasswordDTO.getNewPassword()));
        userRepository.save(user);

        ApiResponse<String> response = ApiResponse.success("Password changed successfully");
        
        return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<ApiResponse<String>> deleteUser(Long userId) {
		User user = userRepository.findById(userId)
                .orElseThrow(() -> CustomException.userNotFound(userId));
		
		// Soft delete - just deactivate the user
        user.setIsActive(false);
        userRepository.save(user);
        
        ApiResponse<String> response = ApiResponse.success("User deleted successfully");

        return new ResponseEntity<>(response, HttpStatus.OK);

	}

	@Override
	@Transactional(readOnly = true)
	public ResponseEntity<ApiResponse<List<UserResponseDTO>>> getAllUsers() {
		List<UserResponseDTO> users = userRepository.findAll().stream()
                .map(converter::convertToUserResponseDTO)
                .collect(Collectors.toList());
		
		ApiResponse<List<UserResponseDTO>> response = ApiResponse.success("Users retrived Successfully", users);
		return new ResponseEntity<>(response,HttpStatus.OK);
	}
	

}

package com.tcs.jfd.fooddelivery.user.bean;

public enum Role {
	CUSTOMER, RESTAURANT_OWNER, DELIVERY_PERSON, ADMIN
}

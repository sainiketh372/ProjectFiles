package com.tcs.jfd.fooddelivery.user.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.jfd.fooddelivery.user.dto.ApiResponse;
import com.tcs.jfd.fooddelivery.user.dto.ChangePasswordDTO;
import com.tcs.jfd.fooddelivery.user.dto.LoginResponseDTO;
import com.tcs.jfd.fooddelivery.user.dto.UpdateProfileDTO;
import com.tcs.jfd.fooddelivery.user.dto.UserLoginDTO;
import com.tcs.jfd.fooddelivery.user.dto.UserRegistrationDTO;
import com.tcs.jfd.fooddelivery.user.dto.UserResponseDTO;
import com.tcs.jfd.fooddelivery.user.service.UserService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor // Construction Injection
public class UserController {

	private final UserService userService;

	@PostMapping("/register")
	public ResponseEntity<ApiResponse<UserResponseDTO>> registerUser(
			@Valid @RequestBody UserRegistrationDTO registrationDTO) {
		return userService.registerUser(registrationDTO);
	}

	@PostMapping("/login")
	public ResponseEntity<ApiResponse<LoginResponseDTO>> loginUser(@Valid @RequestBody UserLoginDTO loginDTO) {
		return userService.loginUser(loginDTO);
	}

	@GetMapping("/{userId}")
	public ResponseEntity<ApiResponse<UserResponseDTO>> getUserById(@PathVariable Long userId) {
		return userService.getUserById(userId);
	}

	@GetMapping("getallusers")
	public ResponseEntity<ApiResponse<List<UserResponseDTO>>> getAllUsers() {
		return userService.getAllUsers();
	}

	@PutMapping("/userId/{userId}")
	public ResponseEntity<ApiResponse<UserResponseDTO>> updateProfile(@PathVariable Long userId,
			@Valid @RequestBody UpdateProfileDTO updateProfileDTO) {
		return userService.updateProfile(userId, updateProfileDTO);
	}

	@PutMapping("/{userId}/password")
	public ResponseEntity<ApiResponse<String>> changePassword(@PathVariable Long userId,
			@Valid @RequestBody ChangePasswordDTO changePasswordDTO) {
		return userService.changePassword(userId, changePasswordDTO);
	}

	@DeleteMapping("/{userId}")
	public ResponseEntity<ApiResponse<String>> deleteUser(@PathVariable Long userId) {
		return userService.deleteUser(userId);
	}
}

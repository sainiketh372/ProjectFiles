package com.tcs.jfd.fooddelivery.user.bean;

public enum AddressType {
	HOME, WORK, OTHER
}

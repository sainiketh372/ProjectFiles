package com.tcs.jfd.fooddelivery.gateway.filter;

import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.stereotype.Component;

/**
 * JWT Authentication Filter
 * ----------------------------------
 * Temporarily DISABLED.
 * This filter will be enabled in the final phase
 * when JWT security is added to the API Gateway.
 */
@Component
public class AuthenticationFilter
        extends AbstractGatewayFilterFactory<AuthenticationFilter.Config> {

    public AuthenticationFilter() {
        super(Config.class);
    }

    @Override
    public GatewayFilter apply(Config config) {
        // JWT is disabled for now
        return (exchange, chain) -> chain.filter(exchange);
    }

    public static class Config {
        // Future configuration properties
    }
}

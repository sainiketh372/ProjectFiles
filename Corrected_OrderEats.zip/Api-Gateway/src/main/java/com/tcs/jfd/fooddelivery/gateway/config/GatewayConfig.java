package com.tcs.jfd.fooddelivery.gateway.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayConfig {

    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {

        return builder.routes()

                // User Service
                .route("user-service", r -> r
                        .path("/api/users/**")
                        .uri("lb://USER-SERVICE"))

                // Restaurant Service
                .route("restaurant-service", r -> r
                        .path("/api/restaurants/**")
                        .uri("lb://RESTAURANT-SERVICE"))

                // Order Service
                .route("order-service", r -> r
                        .path("/api/orders/**")
                        .uri("lb://ORDER-SERVICE"))

                // Payment Service
                .route("payment-service", r -> r
                        .path("/api/payments/**")
                        .uri("lb://PAYMENT-SERVICE"))

                // Delivery Service
                .route("delivery-service", r -> r
                        .path("/api/deliveries/**")
                        .uri("lb://DELIVERY-SERVICE"))

                .build();
    }
}
